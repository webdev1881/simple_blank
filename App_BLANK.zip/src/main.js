window.onload = function(){
let v = console;
let d = document;



















//document.getElementsByClassName("cbalink")[0].remove()
}

